from flask import Flask,render_template,request
import urllib, json
import pymysql
import matplotlib.pyplot as plt
# import matplotlib.patches as mpatches
import numpy
import base64
import StringIO

con = pymysql.connect(host = 'localhost',user = 'root',passwd = '',db = 'jsondet')
cursor = con.cursor()

def timedelgr1():
    querymaxdel = "select max(BatchId) from delclusterhistory"

    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []
    y2 = []
    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count = count + 1

            if count > 24:
                break;
            x.append(int(count))
            query = "SELECT  sum(pfiles),sum(dfiles),sum(ffiles) from delclusterhistory " \
                    "where destinationsite='UTA_SWT2' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))
                if (str(row[2]) == 'None'):
                    y2.append(0)
                else:
                    y2.append(int(row[2]))

        img = StringIO.StringIO()


        plt.ylabel('No.of Files')
        plt.title('UTA_SWT2 - Deletion')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        # plt.xticks(x)
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='o',color='blue')
        plt.plot(x, y1,marker='^',color='green')
        plt.plot(x, y2, marker='*',color='red')
        # for i, j in zip(x, y0):
        #      plt.annotate(str(j), xy=(i - 0.25, j +1.5), color='blue')
        # for i, j in zip(x, y1):
        #      plt.annotate(str(j), xy=(i - 0.25, j + 1.5), color='green')
        # for i, j in zip(x, y2):
        #     plt.annotate(str(j), xy=(i - 0.25, j + 1.5), color='red')
        plt.legend(['Planned', 'Done', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()
        print 'done'

    return plot_url


def timedelgr2():
    querymaxdel = "select max(BatchId) from delclusterhistory"
    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []
    y2 = []
    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count = count + 1

            if count > 24:
                break;
            x.append(int(count))
            query = "SELECT  sum(pfiles),sum(dfiles),sum(ffiles) from delclusterhistory " \
                    "where destinationsite='SWT2_CPB' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))
                if (str(row[2]) == 'None'):
                    y2.append(0)
                else:
                    y2.append(int(row[2]))

        img = StringIO.StringIO()

        plt.ylabel('No.of Files')
        plt.title('SWT2_CPB - Deletion')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='o',color='blue')
        plt.plot(x, y1,marker='^',color='green')
        plt.plot(x, y2, marker='*',color='red')
        # for i, j in zip(x, y0):
        #     plt.annotate(str(j), xy=(i - 0.25, j + 1.5), color='blue')
        # for i, j in zip(x, y1):
        #     plt.annotate(str(j), xy=(i - 0.25, j + 1.5), color='green')
        # for i, j in zip(x, y2):
        #     plt.annotate(str(j), xy=(i - 0.25, j + 1.5), color='red')
        plt.legend(['Planned', 'Done', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()

    return plot_url


def timedelgr3():
    querymaxdel = "select max(BatchId) from delclusterhistory"
    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []
    y2 = []
    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count = count + 1

            if count > 24:
                break;
            x.append(int(count))
            query = "SELECT  sum(pfiles),sum(dfiles),sum(ffiles) from delclusterhistory " \
                    "where destinationsite='OU_OSCER_ATLAS' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))
                if (str(row[2]) == 'None'):
                    y2.append(0)
                else:
                    y2.append(int(row[2]))

        img = StringIO.StringIO()

        plt.ylabel('No.of Files')
        plt.title('OU_OSCER_ATLAS - Deletion')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='o',color='blue')
        plt.plot(x, y1,marker='^',color='green')
        plt.plot(x, y2, marker='*',color='red')
        # for i, j in zip(x, y0):
        #     plt.annotate(str(j), xy=(i - 0.25, j + 1.5), color='blue')
        # for i, j in zip(x, y1):
        #     plt.annotate(str(j), xy=(i - 0.25, j + 1.5), color='green')
        # for i, j in zip(x, y2):
        #     plt.annotate(str(j), xy=(i - 0.25, j + 1.5), color='red')
        plt.legend(['Planned', 'Done', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()

    return plot_url

def timetransrcgr1():
    querymaxdel = "select max(BatchId) from transclusterhistory"

    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []

    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count = count + 1

            if count > 24:
                break;
            x.append(int(count))
            query = "SELECT  sum(tfiles),sum(ffiles) from transclusterhistory " \
                    "where sourcesite='UTA_SWT2' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))



        img = StringIO.StringIO()


        plt.ylabel('No.of Files')
        plt.title('UTA_SWT2 - Transfer (Source site)')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='^',color='green')
        plt.plot(x, y1,marker='*',color='red')
        plt.legend(['Transferred', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()


    return plot_url

def timetransrcgr2():
    querymaxdel = "select max(BatchId) from transclusterhistory"

    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []

    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count = count + 1

            if count > 24:
                break;
            x.append(int(count))
            query = "SELECT  sum(tfiles),sum(ffiles) from transclusterhistory " \
                    "where sourcesite='SWT2_CPB' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))



        img = StringIO.StringIO()

        plt.ylabel('No.of Files')
        plt.title('SWT2_CPB - Transfer (Source site)')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='^',color='green')
        plt.plot(x, y1,marker='*',color='red')
        plt.legend(['Transferred', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()

    return plot_url

def timetransrcgr3():
    querymaxdel = "select max(BatchId) from transclusterhistory"

    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []

    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count = count + 1

            if count > 24:
                break;
            x.append(int(count))
            query = "SELECT  sum(tfiles),sum(ffiles) from transclusterhistory " \
                    "where sourcesite='OU_OSCER_ATLAS' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))


        img = StringIO.StringIO()

        plt.ylabel('No.of Files')
        plt.title('OU_OSCER_ATLAS - Transfer (Source site)')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='^',color='green')
        plt.plot(x, y1,marker='*',color='red')
        plt.legend(['Transferred', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()

    return plot_url

def timetrandesgr1():
    querymaxdel = "select max(BatchId) from transclusterhistory"

    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []

    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count=count+1

            if count>24:
                break;
            x.append(int(count))

            query = "SELECT  sum(tfiles),sum(ffiles) from transclusterhistory " \
                    "where destinationsite='UTA_SWT2' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))


        img = StringIO.StringIO()

        plt.ylabel('No.of Files')
        plt.title('UTA_SWT2 - Transfer (Destination site)')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='^',color='green')
        plt.plot(x, y1,marker='*',color='red')
        plt.legend(['Transferred', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()

    return plot_url

def timetrandesgr2():
    querymaxdel = "select max(BatchId) from transclusterhistory"

    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []

    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count=count+1

            if count>24:
                break;
            x.append(int(count))

            query = "SELECT  sum(tfiles),sum(ffiles) from transclusterhistory " \
                    "where destinationsite='SWT2_CPB' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))



        img = StringIO.StringIO()

        plt.ylabel('No.of Files')
        plt.title('SWT2_CPB - Transfer (Destination site)')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='^',color='green')
        plt.plot(x, y1,marker='*',color='red')
        plt.legend(['Transferred', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()

    return plot_url


def timetrandesgr3():
    querymaxdel = "select max(BatchId) from transclusterhistory"

    cursor.execute(querymaxdel)
    batchtot = cursor.fetchall()
    y0 = []
    y1 = []

    x=[]
    for row in batchtot:

        count=0
        for j in range(int(row[0]),0,-1):

            count=count+1

            if count>24:
                break;
            x.append(int(count))

            query = "SELECT  sum(tfiles),sum(ffiles) from transclusterhistory " \
                    "where destinationsite='OU_OSCER_ATLAS' and BatchId=" + str(j)

            cursor.execute(query)
            datatimegr = cursor.fetchall()
            for row in datatimegr:
                if (str(row[0]) == 'None'):
                    y0.append(0)
                else:
                    y0.append(int(row[0]))
                if (str(row[1]) == 'None'):
                    y1.append(0)
                else:
                    y1.append(int(row[1]))


        img = StringIO.StringIO()

        plt.ylabel('No.of Files')
        plt.title('OU_OSCER_ATLAS - Transfer (Destination site)')

        plt.xlabel("Time in hours (Last 24 hrs)")
        plt.ylabel("No.of files")
        plt.xticks(numpy.arange(0, 24, step=2))
        plt.plot(x,y0,marker='^',color='green')
        plt.plot(x, y1,marker='*',color='red')

        plt.legend(['Transferred', 'Failed'], loc='upper left')
        #  plt.legend(bbox_to_anchor=(1.05, 1), loc=3, borderaxespad=0.)
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plt.gcf().clear()

    return plot_url




