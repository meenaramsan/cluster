from flask import Flask,render_template,request
import urllib, json
import pymysql
import matplotlib.pyplot as plt
# import matplotlib.patches as mpatches
import numpy
import base64
import StringIO
from timegraph import timetrandesgr3,timedelgr1,timedelgr2,timedelgr3,timetransrcgr1,timetransrcgr2,timetransrcgr3,timetrandesgr1,timetrandesgr2

app = Flask(__name__)

con = pymysql.connect(host = 'localhost',user = 'root',passwd = '',db = 'jsondet')
cursor = con.cursor()


@app.route('/')
def main():
    # return render_template('deletion/uta2.html')

        plottimeuta=timedelgr1()
        print 'p1'
        plottimecpb=timedelgr2()
        plottimeoscer=timedelgr3()
        plottimetransrcuta=timetransrcgr1()
        plottimetransrccpb=timetransrcgr2()
        plottimetransrcosc=timetransrcgr3()
        plottimetrandesuta=timetrandesgr1()
        plottimetrandescpb=timetrandesgr2()
        plottimetrandesosc=timetrandesgr3()


        return render_template('home.html',plottimeuta=plottimeuta,plottimecpb=plottimecpb,
                               plottimetransrcuta=plottimetransrcuta,plottimetransrccpb=plottimetransrccpb,
                               plottimeoscer=plottimeoscer,plottimetransrcosc=plottimetransrcosc,
                               plottimetrandesuta=plottimetrandesuta,plottimetrandescpb=plottimetrandescpb,
                               plottimetrandesosc=plottimetrandesosc,
                               imgval1='visible',imgval2='visible',imgval3='visible',
                               imgval4='visible',imgval5='visible',imgval6='visible',
                               imgval7='visible',imgval8='visible',imgval9='visible',ddval='1')

@app.route("/deletion/uta_swt2.html")
def viewdelgraph1():
    plottimeuta = timedelgr1()
    return render_template('deletion/uta2.html',plottimeuta=plottimeuta)

@app.route("/deletion/swt2_cpb.html")
def viewdelgraph2():
    plottimecpb = timedelgr2()
    return render_template('deletion/cpb.html',plottimecpb=plottimecpb)

@app.route("/deletion/oscer_atlas.html")
def viewdelgraph3():
    plottimeoscer = timedelgr3()
    return render_template('deletion/oscer.html', plottimeoscer=plottimeoscer)

@app.route("/transfer/source/uta_swt2.html")
def viewtransrcgraph1():
    plottimetransrcuta = timetransrcgr1()
    return render_template('transfer/source/uta2.html', plottimetransrcuta=plottimetransrcuta)

@app.route("/transfer/source/swt2_cpb.html")
def viewtransrcgraph2():
    plottimetransrccpb = timetransrcgr2()
    return render_template('transfer/source/cpb.html', plottimetransrccpb=plottimetransrccpb)

@app.route("/transfer/source/oscer_atlas.html")
def viewtransrcgraph3():
    plottimetransrcosc = timetransrcgr3()
    return render_template('transfer/source/oscer.html', plottimetransrcosc=plottimetransrcosc)

@app.route("/transfer/destination/uta_swt2.html")
def viewtrandesgraph1():
    plottimetrandesuta = timetrandesgr1()
    return render_template('transfer/destination/uta2.html', plottimetrandesuta=plottimetrandesuta)

@app.route("/transfer/destination/swt2_cpb.html")
def viewtrandesgraph2():
    plottimetrandescpb = timetrandesgr2()
    return render_template('transfer/destination/cpb.html', plottimetrandescpb=plottimetrandescpb)

@app.route("/transfer/destination/oscer_atlas.html")
def viewtrandesgraph3():
    plottimetrandesosc = timetrandesgr3()
    return render_template('transfer/destination/oscer.html', plottimetrandesosc=plottimetrandesosc)

@app.route("/config")
def config():
    cursor.execute("select count(*) from thresholds")
    cntres = cursor.fetchall()
    cntval=''
    for row in cntres:
        cntval=row[0]
    # utadel,utasrc,utades,cpbdel,cpbsrc,cpbdes,oscdel,oscsrc,oscdel=loadconfig()
    # return render_template('config.html',configres='',utadel=utadel,utasrc=utasrc,utades=utades)
    print cntval
    if(cntval==0):
        return render_template('config.html', configres='', utadel='', utasrc='', utades='',cpbdel='',cpbsrc='',cpbdes='',oscdel='',oscsrc='',oscdes='')
    else:
        utadel, utasrc, utades, cpbdel, cpbsrc, cpbdes, oscdel, oscsrc, oscdes = loadconfig()
        return render_template('config.html', configres='', utadel=utadel, utasrc=utasrc, utades=utades,cpbdel=cpbdel,cpbsrc=cpbsrc,cpbdes=cpbdes,oscdel=oscdel,oscsrc=oscsrc,oscdes=oscdes)

@app.route("/saveconfig", methods=['GET', 'POST'])
def saveconfig():
    if request.method == "POST":

        cursor.execute("delete from thresholds")
        con.commit()

        del1=request.form['del1']
        transrc1 = request.form['transrc1']
        trandes1 = request.form['trandes1']
        sitename1='UTA_SWT2'

        cursor.execute("INSERT INTO thresholds (Sitename, Deletionval,Transfersrcval,Transferdesval) VALUES (%s,%s,%s,%s)",(sitename1, del1, transrc1, trandes1))
        con.commit()

        del2 = request.form['del2']
        transrc2 = request.form['transrc2']
        trandes2 = request.form['trandes2']
        sitename2 = 'SWT2_CPB'
        cursor.execute(
            "INSERT INTO thresholds (Sitename, Deletionval,Transfersrcval,Transferdesval) VALUES (%s,%s,%s,%s)",
            (sitename2, del2, transrc2, trandes2))
        con.commit()
        del3 = request.form['del3']
        transrc3 = request.form['transrc3']
        trandes3 = request.form['trandes3']
        sitename3 = 'OU_OSCER_ATLAS'
        cursor.execute(
            "INSERT INTO thresholds (Sitename, Deletionval,Transfersrcval,Transferdesval) VALUES (%s,%s,%s,%s)",
            (sitename3, del3, transrc3, trandes3))
        con.commit()
        return render_template('config.html',configres="Config saved successfully",utadel='', utasrc='', utades='',cpbdel='',cpbsrc='',cpbdes='',oscdel='',oscsrc='',oscdes='')

def loadconfig():
    cursor.execute('select Sitename,Deletionval,Transfersrcval,Transferdesval from thresholds')
    configval=cursor.fetchall()
    utaalert = str(configval[0]).split(',')
    cpbalert=str(configval[1]).split(',')
    oscalert=str(configval[2]).split(',')
    utav1=utaalert[1].replace("'", "")
    print 'utav1'
    print utav1
    utav2=utaalert[2].replace("'", "")
    utav3=utaalert[3].replace("')", "")
    cpbv1 = cpbalert[1].replace("'", "")
    cpbv2 = cpbalert[2].replace("'", "")
    cpbv3 = cpbalert[3].replace("')", "")
    oscv1 = oscalert[1].replace("'", "")
    oscv2 = oscalert[2].replace("'", "")
    oscv3 = oscalert[3].replace("')", "")
    return utav1,utav2,utav3.replace("'", ""),cpbv1,cpbv2,cpbv3.replace("'", ""),oscv1,oscv2,oscv3.replace("'", "")



@app.route("/viewtimegraph", methods=['GET', 'POST'])
def viewtimegraph():
    if request.method == "POST":
        selval=str(request.form['option'])

        plottimeuta = timedelgr1()
        plottimecpb = timedelgr2()
        plottimeoscer = timedelgr3()
        plottimetransrcuta = timetransrcgr1()
        plottimetransrccpb = timetransrcgr2()
        plottimetransrcosc = timetransrcgr3()
        plottimetrandesuta = timetrandesgr1()
        plottimetrandescpb = timetrandesgr2()
        plottimetrandesosc = timetrandesgr3()
        v = 'visible'
        n = 'none'
        if selval=='1':
            return render_template('home.html', plottimeuta=plottimeuta, plottimecpb=plottimecpb,
                                   plottimetransrcuta=plottimetransrcuta, plottimetransrccpb=plottimetransrccpb,
                                   plottimeoscer=plottimeoscer, plottimetransrcosc=plottimetransrcosc,
                                   plottimetrandesuta=plottimetrandesuta, plottimetrandescpb=plottimetrandescpb,
                                   plottimetrandesosc=plottimetrandesosc,
                                   imgval1=v, imgval2=n, imgval3=n,
                                   imgval4=v, imgval5=n, imgval6=n,
                                   imgval7=v, imgval8=n, imgval9=n,ddval='1')
        if selval=='2':
            return render_template('home.html', plottimeuta=plottimeuta, plottimecpb=plottimecpb,
                               plottimetransrcuta=plottimetransrcuta, plottimetransrccpb=plottimetransrccpb,
                               plottimeoscer=plottimeoscer, plottimetransrcosc=plottimetransrcosc,
                               plottimetrandesuta=plottimetrandesuta, plottimetrandescpb=plottimetrandescpb,
                               plottimetrandesosc=plottimetrandesosc,
                               imgval1=n, imgval2=v, imgval3=n,
                               imgval4=n, imgval5=v, imgval6=n,
                               imgval7=n, imgval8=v, imgval9=n,ddval='2')
        else:
           return render_template('home.html', plottimeuta=plottimeuta, plottimecpb=plottimecpb,
                                   plottimetransrcuta=plottimetransrcuta, plottimetransrccpb=plottimetransrccpb,
                                   plottimeoscer=plottimeoscer, plottimetransrcosc=plottimetransrcosc,
                                   plottimetrandesuta=plottimetrandesuta, plottimetrandescpb=plottimetrandescpb,
                                   plottimetrandesosc=plottimetrandesosc,
                                   imgval1=n, imgval2=n, imgval3=v,
                                   imgval4=n, imgval5=n, imgval6=v,
                                   imgval7=n, imgval8=n, imgval9=v,ddval='3')



# if __name__ == '__main__':
#     app.run()
if __name__ == '__main__':
    app.run(debug=True,port=4998)